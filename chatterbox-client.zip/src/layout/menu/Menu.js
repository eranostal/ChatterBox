import React, { Fragment, useContext } from 'react';

import AuthContext from '../../context/auth/authContext';

import './Menu.css';

const Menu = () => {

    const authContext = useContext(AuthContext);

    const { isAuthenticated, loading, logoutUser } = authContext;
    

    return (
        <nav className='main-menu'>
            {!loading && isAuthenticated === true ? (
                <Fragment>
                    Create Room | Join Room | Friends (0) |  Settings Cog | <a onClick={() => logoutUser()}>Logout</a>
                </Fragment>
            ) : (
                <Fragment>
                    <a href='/'>Leave Room</a>
                </Fragment>
            )}
        </nav>
    )
}

export default Menu