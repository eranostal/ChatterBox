import React, { useState, useEffect } from 'react';
import { Link, useHistory } from 'react-router-dom';
import io from 'socket.io-client';

import './JoinRoomForm.css';

let socket;

const JoinRoomForm = () => {

    let history = useHistory();

    //SET THIS TO AN ENVRIONEMENT VARIABLE
    const ENDPOINT = 'https://chatter-box-application.herokuapp.com/';

    const [roomInfo, setRoomInfo] = useState({
        userName: '', //Pull this when logged in using an effect
        roomName: '',
        roomPassword: ''
    });

    const { userName, roomName, roomPassword } = roomInfo;

    useEffect(() => {

        //If not logged in, set temporary name. Change to actual name instead of getItem?
        setRoomInfo({...roomInfo, userName: localStorage.getItem('tempName')});

    }, []);

    const onChange = (e) => {
        setRoomInfo({...roomInfo, [e.target.name]: e.target.value});
    }

    useEffect(() => {
        //If not logged in, set temporary name. Change to actual name instead of getItem?
        setRoomInfo({...roomInfo, userName: localStorage.getItem('tempName')});

    }, []);

    const onSubmit = (e) => {
        
        e.preventDefault();

        //Connect to the end point.
        socket = io(ENDPOINT);

        socket.emit('checkRoom', { roomName, roomPassword }, (findRoom) => {

            localStorage.tempName = userName;

            const roomInfo = {
                pathname: findRoom.pathname,
                roomName: findRoom.roomName,
                userName,
                roomPassword: findRoom.roomPassword,
            }

            history.push(findRoom.pathname, { roomInfo });
        })


    }

    return (
        <form className='join-room-form' onSubmit={onSubmit}>
            <div className='form-title'>Join Room</div>
            <label>Room Name:*</label>
            <div className='field'>
                <input type='text' name='roomName' value={roomName} onChange={onChange}/>
                <a className='clear-field'>x</a>
            </div>
            <label>Room Password:*</label>
            <div className='field'>
                <input type='password' name='roomPassword' value={roomPassword} onChange={onChange}/>
                <a className='clear-field'>x</a>
            </div>
            <label>Username:*</label>
            <div className='field'>
                <input type='text' name='userName' value={userName} onChange={onChange}/>
                <a className='clear-field'>x</a>
            </div>
            {/* Change this onClick to be more for checking if values match */}
            <input type='submit' value='Join Room'/>
        </form>
    )
}

export default JoinRoomForm;