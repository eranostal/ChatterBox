import React from 'react';

import './User.css';

const User = ({ user }) => {

    console.log('This user is:')
    console.log(user.name);

    return (
        <div className='user'>
            { user.name }
        </div>
    )
};

export default User;