import React, { useState, useContext } from 'react';

import AuthContext from '../../context/auth/authContext';
import AlertContext from '../../context/alert/alertContext';

import './RegisterForm.css'

const RegisterForm = () => {

    const [user, setUser] = useState({
        dob: '',
        email: '',
        password: '',
        confirmPassword: ''
    });

    const authContext = useContext(AuthContext);
    const { registerUser, loading } = authContext;

    const alertContext = useContext(AlertContext);
    const { setAlert } = alertContext;

    
    //Destructure
    const { dob, email, password, confirmPassword } = user;

    //Why is [e.target.name] in brackets?
    const onChange = (e) => {
        setUser({...user, [e.target.name]: e.target.value});
    }

    const onSubmit = (e) => {
        e.preventDefault();

        //CONVERT DATE HERE
        //CHECK THAT PASSWORD AND CONFIRMPASSWORD MATCH
        if(password !== confirmPassword){
            setAlert('Passwords do not match!', 'danger');
        } else {
            registerUser(user);
        }
        
        //DO I CHANGE LOADING HERE OR IN AUTHSTATE????
    }

    //REMOVE TEXT FROM FIELDS NEEDS TO UPDATE STATE
    const removeFieldText = (fieldID) => {

        document.getElementById(fieldID).value = '';
        
        setUser({...user, [document.getElementById(fieldID).name]: ''});
    
    }


    return (
        <form className='register-form' onSubmit={onSubmit}>
            <div className='form-title'>Sign Up (It's Free!)</div>
            <label>Date of Birth (must be 18 or older):</label>
            <div className='field'><input id='register-date' name='dob' type='date' value={dob} onChange={onChange}/><a className='clear-field' onClick={() => removeFieldText('register-date')}>x</a></div>
            <label>Email:</label>
            <div className='field'><input id='register-email' name='email' type='email' value={email} onChange={onChange} placeholder='e.g. rcclark@gmail.com'/><a className='clear-field' onClick={() => removeFieldText('register-email')}>x</a></div>
            <label>Password (minimum six characters):</label>
            <div className='field'><input id='register-password' name='password' type='password' value={password} onChange={onChange} placeholder='password'/><a className='clear-field' onClick={() => removeFieldText('register-password')}>x</a></div>
            <label>Confirm Password:</label>
            <div className='field'><input id='confirm-password' name='confirmPassword' type='password' value={confirmPassword} onChange={onChange} placeholder='password'/><a className='clear-field' onClick={() => removeFieldText('confirm-password')}>x</a></div>
            <input type='submit' value='Register Account'/>
            {/* SIGN-UPS FOR OAUTH HERE */}
        </form>
    )

}

export default RegisterForm;