import { DISPLAY_LOGIN, HIDE_LOGIN, DISPLAY_FORM } from '../types';

export default (state, action) => {
    switch(action.type) {
        case DISPLAY_LOGIN:
            return {
                ...state,
                isDisplayed: action.payload
            }
        case HIDE_LOGIN:
            return {
                ...state,
                isDisplayed: action.payload
            }
        case DISPLAY_FORM:
            return {
                ...state,
                form: action.payload
            }
        default:
            return state
    }
}