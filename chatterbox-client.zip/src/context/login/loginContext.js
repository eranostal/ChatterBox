import { createContext } from 'react';

const loginContext = createContext();

export default loginContext;