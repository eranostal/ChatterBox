import React, { useContext, useEffect } from 'react';

//IMPORT COMPONENTS
import CreateJoin from '../../components/create_join/CreateJoin';

//IMPORT CONTEXTS
import LoginContext from '../../context/login/loginContext';
import AuthContext from '../../context/auth/authContext';

import './Root.css';

const Root = () => {

    const loginContext = useContext(LoginContext);

    const authContext = useContext(AuthContext);
    const { isAuthenticated, loading, loadUser } = authContext;

    useEffect(() => {        
        loadUser();
    }, []);


    return(
        <div className='root-page'>
            <div className='introduction'><h1>Welcome to <span className='grey-box'>Chatterbox</span></h1><h2>ver 0.1a</h2></div>
            <CreateJoin/>
        </div>
    )
}

export default Root;

