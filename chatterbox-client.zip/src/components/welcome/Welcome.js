import React, { useState, useContext, useEffect } from 'react';

import AuthContext from '../../context/auth/authContext';

import './Welcome.css';
//THE PROBLEM IS HERE!!
const Welcome = () => {
    
    //REMOVE REPLACE WITH USER
    const [userInfo, setUserInfo] = useState({
        updUserName: '',
        updFirstName: '',
        updLastName: ''
    });

    const { updUserName, updFirstName, updLastName } = userInfo;

    const authContext = useContext(AuthContext);
    const { user, updateUser, loading } = authContext;

    const { _id, userName, email } = user;

    //MAKE SURE YOU USE defaultValue FOR THESE
    useEffect(() => {

        if(userName === '') {
            let defaultUserName = email.substring(0, email.lastIndexOf('@'));
            setUserInfo({ updUserName: defaultUserName });
        } else {
            setUserInfo({ updUserName: userName });
        }


    }, []);

    const onChange = (e) => {
        setUserInfo({...userInfo, [e.target.name]: e.target.value});
    }

    //LOGIN A USER
    const onSubmit = (e) => {
        e.preventDefault();


        updateUser(updUserName, updFirstName, updLastName);

    }


    //REMOVE TEXT FROM FIELDS NEEDS TO UPDATE STATE
    const removeFieldText = (fieldID) => {

        document.getElementById(fieldID).value = '';
        setUserInfo({...userInfo, [document.getElementById(fieldID).name]: ''});
    
    }




    return (
        <div className='welcome-box'>
            <div className='welcome-text'>Welcome!<br/>Before we get you to chatting, we just need a few more details.</div>
            <div className='welcome-box-inner'>
                <form className='details-form' onSubmit={onSubmit}>
                    <div className='form-title'>Additional Info</div>
                    <label>Default Username*:</label>
                    <div className='field'>
                        <input id='additional-username' type='text' name='updUserName' defaultValue={updUserName} value={updUserName} onChange={onChange} placeholder='e.g. SpoonHammer'/>
                        <a className='clear-field' onClick={() => removeFieldText('additional-username')}>x</a>
                    </div>
                    <label>First Name (Optional):</label>
                    <div className='field'>
                        <input id='additional-first-name' type='text' name='updFirstName' defaultValue={updFirstName} value={updFirstName} onChange={onChange} placeholder='e.g. John'/>
                        <a className='clear-field' onClick={() => removeFieldText('additional-first-name')}>x</a>
                    </div>
                    <label>Last Name (Optional):</label>
                    <div className='field'>
                        <input id='additional-last-name' type='text' name='updLastName' defaultValue={updLastName} value={updLastName} onChange={onChange} placeholder='e.g. Doe'/>
                        <a className='clear-field' onClick={() => removeFieldText('additional-last-name')}>x</a>
                    </div>
                    <input type='submit' value='Update'/>
                </form>
            </div>
            {/*<a onClick={() => logoutUser()}>Logout</a>*/}
        </div>
    )
}

export default Welcome;