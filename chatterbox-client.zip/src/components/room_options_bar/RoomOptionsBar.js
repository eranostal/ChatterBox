import React, { useState, Fragment } from 'react';

import './RoomOptionsBar.css';

const RoomOptionsBar = () => {

    let infoBox, button;

    //Move to form util?
    const infoText = [
        { name: 'collapseBar', value: 'Collapse the room options bar.' },
        { name: 'createChatBox', value: 'Create a new ChatBox.' }
    ]

    //Move this to form util?
    const [tab, openTab] = useState(false);

    const onMouseEnter = (e) => {

        infoBox = document.createElement('div');
        infoBox.className = 'info';
        
        for(let i = 0; i < infoText.length; i++) {
            if(infoText[i].name === e.target.name) {
                infoBox.innerHTML = infoText[i].value;
            }
        }
        
        //Can you do this without the need of the [0]
        button = document.getElementsByName(e.target.name)[0].appendChild(infoBox);
    }

    const onMouseLeave = (e) => {
        infoBox.remove();
        button = null;
    }

    const onClick = (e) => {
        console.log('Clicked');
    }


    return (
        <div className={tab === true ? 'room-options-bar open' : 'room-options-bar'}>
            <a name='expandCollapse' onClick={() => openTab(!tab)} className='open-close-tab'>{tab === true ? <Fragment>&lt;<br/>&lt;<br/>&lt;</Fragment> : <Fragment>&gt;<br/>&gt;<br/>&gt;</Fragment>}</a>
            <div className='options-list'>
                <button className='option' name='createChatBox' onClick={onClick} onMouseEnter={onMouseEnter} onMouseLeave={onMouseLeave}>C</button>
            </div>
        </div>
    )
}

export default RoomOptionsBar;