import React, { useState, useContext, useEffect } from 'react';

import LoginForm from '../login_form/LoginForm';
import RegisterForm from '../register_form/RegisterForm';

//IMPORT CONTEXTS
import LoginContext from '../../context/login/loginContext';
import AuthContext from '../../context/auth/authContext';


import './Login.css';

const Login = () => {

    const loginContext = useContext(LoginContext);
    const { isDisplayed, form, showLogin, hideLogin, displayForm } = loginContext;

    const authContext = useContext(AuthContext);
    //Do I need loadUser here??
    const { isAuthenticated, loadUser, logoutUser } = authContext;

    //SHOW THE LOGIN BOX AND WHICH FORM
    useEffect(() => {


        if(!isAuthenticated){
            showLogin();
        } else {
            hideLogin();
        }

        if(localStorage.getItem('displayForm') === 'login') {
            displayForm('login');
        } else {
            displayForm('register');
        }    

    }, [])


    //If authenticated this should be here.
    return (
        isDisplayed === true ?
        (
            <div className='login-box'>
                <h2 className='slogan'>Some kind of text about how it's great to chat in a giant group and then chat in smaller groups.</h2>
                <div className='login-register-tabs'>
                    <a className={form === 'login' ? 'tab login active' : 'tab login'} onClick={() => displayForm('login')}>Login</a>
                    <a className={form === 'register' ? 'tab register active' : 'tab register'} onClick={() => displayForm('register')}>Register</a>
                </div>
                <div className='login-box-inner'>
                        {form === 'login' ? <LoginForm/> : <RegisterForm/>}
                </div>
            </div>
        ) : (
            null
        )
    )
}

export default Login;