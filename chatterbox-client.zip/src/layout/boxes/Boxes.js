import React from 'react';

import './Boxes.css';

const Boxes = () => {

    //Generate boxes with script
    //Later make some come in and out.
    const boxes = () => {

        let boxArray = [];

        let box = (<div>Does this work?</div>);

        return box;

    }

    let randomInt = (min, max) => {
        return Math.floor(Math.random() * (max - min + 1) + min);
    }

    return (
        <div className='boxes'>
            {boxes}
        </div>
    )

}

export default Boxes;