import React, { useState, useEffect } from 'react';
import CreateRoomForm from '../create_room_form/CreateRoomForm';
import JoinRoomForm from '../join_room_form/JoinRoomForm';

import './CreateJoin.css';

const CreateJoin = () => {

    const [form, setForm] = useState('');


    useEffect(() => {
        if(localStorage.rootDisplayForm === 'join') {
            setForm('join')
        } else {
            setForm('create');
        }
    }, [])

    const displayForm = (formType) => {
        setForm(formType);
        localStorage.setItem('rootDisplayForm', formType);

    }

    return (
        <div className='create-join-box'>
            <h2 className='slogan'>Chat with everyone, chat with groups, just chat!</h2>
            <div className='create-join-tabs'>
                    <a className={form === 'create' ? 'tab create active' : 'tab create'} onClick={() => displayForm('create')}>Create Room</a>
                    <a className={form === 'join' ? 'tab join active' : 'tab join'} onClick={() => displayForm('join')}>Join Room</a>
            </div>
            <div className='create-join-inner'>
                {form === 'join' ? <JoinRoomForm/> : <CreateRoomForm/>}
            </div>
        </div>
    )
}

export default CreateJoin;