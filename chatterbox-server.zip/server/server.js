const express = require('express');
const http = require('http');
const socketio = require('socket.io');
const cors = require('cors');

const PORT = process.env.port || 5000;
let rooms = [];

//SERVER INIT
const app = express();

const server = http.createServer(app);
//Test to see if this works.
const io = socketio(server, {
    cors: {
        origins: '*:*'
    }
});


//MIDDLEWARE
app.use(express.json({ extended: false })); //Do we need this?
//app.use(cors());

//DATABASE

//HELPER FUNCTIONS FOR SOCKET.IO
const { addUser, removeUser, getUser, getUsersInRoom } = require('./roomUsers');

//IO
//On connection means server connection.
io.on('connection', (socket) => {

    socket.on('createRoom', ({ pathname, roomName, roomPassword, roomType }, callback) => {

        console.log('Attempting to add a room...');

        if(roomName === '' || roomPassword === '') return callback({ error: 'Please enter all information' });

        //Check if the room exists already. Change this to room name later???
        const roomExists = rooms.filter((room) => room.pathname === pathname);

        if(roomExists.length > 0) return callback({ error: 'Room already exists' });

        const newRoom = { pathname, roomName, roomPassword, roomType };

        rooms.push(newRoom);

        console.log(rooms);

        callback();

    });

    //Check room.
    socket.on('checkRoom', ({ roomName, roomPassword }, callback) => {

        console.log('Checking a total of: ' + rooms.length + ' rooms.');

        const findRoom = rooms.find((room) => room.roomName === roomName && room.roomPassword === roomPassword);

        if(findRoom === undefined) return callback({ error: 'Room Name or Password Incorrect' });

        callback(findRoom);

    })

    socket.on('join', ({ userName, roomName }, callback) => {

        const { error, user } = addUser({ id: socket.id, name: userName, room: roomName });

        if(error) return callback(error);

        io.to(user.room).emit('message', { user: 'admin', text: `${user.name} has joined!`});

        socket.join(user.room);

        io.to(user.room).emit('getUsers', getUsersInRoom(user.room));

        //SET TO ADMIN IF FIRST IN ROOM.

        callback();

    });

    //Check room.

    //On send message.
    socket.on('sendMessage', (message, callback) => {

        const user = getUser(socket.id);

        console.log(user);

        io.to(user.room).emit('message', { user: user.name, text: message });

        callback();
        
    });

    socket.on('disconnect', () => {

        const user = removeUser(socket.id);

        if(user) {

            io.to(user.room).emit('message', { user: 'admin', text: `${user.name} has left.` });

            //If nobody is in the room, delete it. IS THERE A BETTER WAY??
            if(getUsersInRoom(user.room).length === 0) {
                rooms = rooms.filter((room) => room.pathname.toLowerCase() === user.room);
            }

        }

    });

});


//ROUTES

//START SERVER
server.listen(PORT, () => console.log(`Server started on port ${PORT}`));