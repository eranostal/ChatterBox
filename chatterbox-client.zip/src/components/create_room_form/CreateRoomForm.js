import React, { useState, useEffect } from 'react';
import { Link, useHistory } from 'react-router-dom';
import { v4 as uuid } from 'uuid';
import io from 'socket.io-client';

import './CreateRoomForm.css';

let socket;

const CreateRoomForm = () => {

    let history = useHistory();

    const roomOptions = [
        { value: 'Standard', selected: 'true'},
        { value: 'Office Party', selected: 'false' },
        { value: 'Work', selected: 'false' },
        { value: 'LAN Party', selected: 'false' },
        { value: 'Book Club', selected: 'false' }
    ];

    //Set to an environment variable
    const ENDPOINT = 'https://chatter-box-application.herokuapp.com/';

    const [room, setRoom] = useState({
        roomName: '',
        roomPassword: '',
        userName: '',
        roomType: ''
    });

    const { roomName, roomPassword, userName, roomType } = room;

    useEffect(() => {
        setRoom({...room, userName: localStorage.tempName, roomType: roomOptions[0].value});
    }, []);

    const onChange = (e) => {
        setRoom({...room, [e.target.name]: e.target.value});
    }

    const onSubmit = (e) => {

        //Connect to SocketIO
        e.preventDefault();

        //Disable submit button.
    
        //Connect to the end point.
        socket = io(ENDPOINT);

        console.log('Creating room...');

        //TURN THIS INTO UUID
        const pathname = `room/${roomName}`;

        socket.emit('createRoom', { pathname, roomName, roomPassword, userName, roomType }, (error) => {
            
            if(error) {
                return console.log(error);
            }

            localStorage.setItem('tempName', userName);

            console.log('New room added!');

            history.push(pathname, { room });

        });


    }

    return (
        <form className='create-room-form' autoComplete='off' onSubmit={onSubmit}>
            <div className='form-title'>Create Room</div>
            <label>Room Name:*</label>
            <div className='field'>
                <input type='text' name='roomName' placeholder='e.g. Keiths Business Room' value={roomName} onChange={onChange}/>
                <a className='clear-field' id='temp' name='clear-roomName'>x</a>
            </div>
            <label>Room Password:*</label>
            <div className='field'>
                <input type='password' value={roomPassword} name='roomPassword' onChange={onChange}/>
                <a className='clear-field'>Eye</a>
            </div>
            <label>Username:*</label> {/* GRAB THIS FROM THEIR USERNAME WHEN LOGGED IN or FROM HISTORY */}
            <div className='field'>
                <input type='text' value={userName} name='userName' onChange={onChange}/>
                <a className='clear-field'>x</a>
            </div>
            <label>Room Type:</label>
            <div className='field'> {/* Make this a dynamic component later. No default value. */}
                <select name='roomType' value={roomType} onChange={onChange}>
                    {
                        roomOptions.map((option) => (
                            <option value={option.value} selected={option.selected}>{option.value}</option>
                        ))
                    }
                </select>
                <a className='clear-field'>x</a>
            </div> {/* On this section, also trigger an error */}
            <input type='submit' value='Create Room'/>
        </form>
    )
}

export default CreateRoomForm;