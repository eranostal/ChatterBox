import React, { useState, useContext, useEffect } from 'react';

import LoginContext from '../../context/login/loginContext';
import AuthContext from '../../context/auth/authContext';

import './LoginForm.css';

const LoginForm = () => {

    const [user, setUser] = useState({
        email: '',
        password: ''
    });

    //Destructure state
    const { email, password } = user;

    const authContext = useContext(AuthContext);
    const { loginUser } = authContext;

    const onChange = (e) => {
        setUser({...user, [e.target.name]: e.target.value});
    }

    //LOGIN A USER
    const onSubmit = (e) => {
        e.preventDefault();
        loginUser(user);
    }

    //REMOVE TEXT FROM FIELDS NEEDS TO UPDATE STATE
    const removeFieldText = (fieldID) => {

        document.getElementById(fieldID).value = '';
        setUser({...user, [document.getElementById(fieldID).name]: ''});
    
    }

    

    return (
        <form className='login-form' onSubmit={onSubmit}>
            <div className='form-title'>Login</div>
            <label>Email Address:</label>
            <div className='field'>
                <input id='login-email' name='email' type='email' value={email} onChange={onChange} placeholder='e.g. rcclark@gmail.com'/>
                <a className='clear-field' onClick={() => removeFieldText('login-email')}>x</a>
            </div>
            <label>Password:</label>
            <div className='field'>
                <input id='login-password' name='password' type='password' value={password} onChange={onChange} placeholder='password'/>
                <a className='clear-field' onClick={() => removeFieldText('login-password')}>x</a>
            </div>
            <input type='submit' value='Sign In'/>
            {/* LOGINS FOR OAUTH HERE */}
        </form>
    )
}

export default LoginForm;