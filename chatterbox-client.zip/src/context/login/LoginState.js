import React, { useReducer } from 'react';

//IMPORT CONTEXT DEPENDENCIES
import { DISPLAY_LOGIN, HIDE_LOGIN, DISPLAY_FORM } from '../types';
import LoginContext from './loginContext';
import loginReducer from './loginReducer';

const LoginState = props => {

    const initialState = {
        isDisplayed: false,
        form: 'login'
    }

    const [state, dispatch] = useReducer(loginReducer, initialState);

    //SHOW LOGIN
    const showLogin = () => {
        dispatch({
            type: DISPLAY_LOGIN,
            payload: true
        });

        localStorage.setItem('displayLogin', 'true');
    }

    //HIDE LOGIN
    const hideLogin = () => {
        dispatch({
            type: HIDE_LOGIN,
            payload: false
        });

        localStorage.setItem('displayLogin', 'false');
    }

    //SWITCH FORMS
    const displayForm = (form) => {

        dispatch({
            type: DISPLAY_FORM,
            payload: form
        });

        localStorage.setItem('displayForm', form);

    }


    return (
        <LoginContext.Provider
            value={{
                isDisplayed: state.isDisplayed,
                form: state.form,
                showLogin,
                hideLogin,
                displayForm
            }}
        >
            {props.children}
        </LoginContext.Provider>
    )
}

export default LoginState;