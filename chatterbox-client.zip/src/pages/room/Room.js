import React, { useState, useEffect } from 'react';
import io from 'socket.io-client';
import { useHistory } from 'react-router-dom';

import Users from '../../components/users/Users';
import Input from '../../components/input/Input';
import Messages from '../../components/messages/Messages';
import VideoChat from '../../components/video_chat/VideoChat';

import RoomOptionsBar from '../../components/room_options_bar/RoomOptionsBar';

//Import User Context if any.

import './Room.css';

let socket;

//How do I pass the room info??
const Room = ({ location }) => {

    const history = useHistory();

    const [name, setName] = useState('');
    const [room, setRoom] = useState('');

    const [message, setMessage] = useState('');
    const [messages, setMessages] = useState([]);

    const [users, setUsers] = useState([]);

    //USE THIS AND THEN PUT A TERNARY CONDITIONAL OR WHATEVER TO CHECK FOR THIS!!!
    const [tab, setTab] = useState('messageTab');

    //SET THIS TO AN ENVRIONEMENT VARIABLE
    const ENDPOINT = 'https://chatter-box-application.herokuapp.com/';

    useEffect(() => {

        //Create an endpoint to the server.
        socket = io(ENDPOINT);


        //Find room by slug.
        const name = localStorage.tempName;
        const room = location.pathname;


        socket.emit('join', { name, room }, () => {
            //no callback.
        });


        //What does this do?
        return () => {
            socket.emit('disconnect');
            socket.off();
        };

    }, [location.pathname, ENDPOINT]);

    //Message-handling event. You only want to run this when the messages array changes.
    useEffect(() => {

        socket.on('message', (message) => {
            setMessages([...messages, message]);
        });

    }, [messages]);

    //Getting User Data in room.
    useEffect(() => {

        //We need the "data" keyword here since we're only passing an array and not an object.
        socket.on('getUsers', (data) => {
            setUsers(data);
        })

    }, [users])

    const sendMessage = (e) => {

        e.preventDefault();

        //What does if(message) do here?
        if(message) {
          socket.emit('sendMessage', message, () => setMessage(''));  
        }

    }

    let boxName, boxDraggable;
    let boxPosition = {
        pos1: 0,
        pos2: 0,
        pos3: 0,
        pos4: 0
    }

    const onMouseEnter = (e) => {

        console.log('Why you firing?');

        boxDraggable = document.getElementById('default-chat-header');
        boxName = document.getElementById('default-chat');

        boxDraggable.onmousedown = dragMouseDown;
        
    }

    const onMouseLeave = (e) => {

        console.log('Leaving space');
        
        document.onmouseenter = null;
        
        boxDraggable = null;
        boxName = null;
    
    }

    const dragMouseDown = (e) => {

        e = e || window.event;
        e.preventDefault();

        //Get mouse cursor position at startup.
        boxPosition.pos3 = e.clientX;
        boxPosition.pos4 = e.clientY;
        document.onmouseup = stopDrag;

        //Call a function when the cursor moves.
        document.onmousemove = drag;

    }

    const drag = (e) => {

        e = e || window.event;
        e.preventDefault();

        console.log('Dragging');

        //Calculate new cursor position.
        boxPosition.pos1 = boxPosition.pos3 - e.clientX;
        boxPosition.pos2 = boxPosition.pos4 - e.clientY;
        boxPosition.pos3 = e.clientX;
        boxPosition.pos4 = e.clientY;

        boxName.style.top = (boxName.offsetTop - boxPosition.pos2) + 'px';
        boxName.style.left = (boxName.offsetLeft - boxPosition.pos1) + 'px';

    }

    const stopDrag = (e) => {
        console.log('Dragging stopped');
        document.onmouseup = null;
        document.onmousemove = null;
    }


    return (
        <div className='room'>
            {/*<RoomOptionsBar/>*/}
            <div id='default-chat' className='chat-box' /*draggable='true' style={{left: '500px', top: '200px'}}*/>
                <div id='default-chat-header' /*onMouseEnter={onMouseEnter} onMouseLeave={onMouseLeave}*/ className='chat-box-header'>
                    <h2 className='box-name'>General Chat</h2>
                    <div className='options'>
                        {/* M = Messages, V = Video, Y = Youtube (maybe later) */}
                        <button className={tab === 'messageTab' ? 'option selected' : 'option'} name='messageTab' onClick={(e) => setTab(e.target.name)}>M</button>
                        <button className={tab === 'videoTab' ? 'option selected' : 'option'} name='videoTab' onClick={(e) => setTab(e.target.name)}>V</button>
                        <button className={tab === 'watchTab' ? 'option selected' : 'option'} name='watchTab' onClick={(e) => setTab(e.target.name)}>Y</button>
                    </div>
                </div>
                <div className='chat-box-inner'>
                    <Users users={users}/>
                    { tab === 'messageTab' && <Messages messages={messages} name={name}/> }
                    { tab === 'videoTab' && <VideoChat/> }
                    { tab === 'watchTab' && <div>Coming Soon</div> }
                    <Input message={message} setMessage={setMessage} sendMessage={sendMessage}/>
                </div>
            </div>
            
        </div>
    )
};

export default Room;