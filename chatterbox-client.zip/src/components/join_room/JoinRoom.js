import React, { useState } from 'react';
import { Link } from 'react-router-dom';

import './Join.css';

const Join = () => {

    //MOVE INTO CONTEXT
    const [name, setName] = useState('');
    const [room, setRoom] = useState('');

    return (
        <div className='join'>
            <h3>Join a Room</h3>
            <label>User Name:</label>
            <input placeholder='User Name' className='user-name' type='text' onChange={(e) => setName(e.target.value)}/> {/* Have Toggle Between Username & First Name? (Settings) & Autofill */}
            <label>Room Name:</label>
            <input placeholder='Room Name' className='room-name' type='text' onChange={(e) => setRoom(e.target.value)}/>
            {/* ROOM PASSWORD HERE REQUIRED */}
            {/* FRIENDS ROOM LIST HERE */}
            <Link onClick={(e) => (!name || room) ? e.preventDefault() : null} to={`/room/${room}`}/>
                <input type='submit' value='Join'/>
            <Link/>
        </div>
    )
}

export default Join;