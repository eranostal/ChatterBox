import React from 'react';

//COMPONENTS AND LAYOUT
import Menu from '../menu/Menu';

//IMPORT LOGO IMAGE

import './Header.css';

const Header = () => {

    return (
        <header className='main-header'>
            <div className='logo-temp'>LOGO</div>
            {/*<div className='room-info'>[ROOM INFO] | <a href='/'>Leave Room</a></div>*/}
            <Menu/>
        </header>
    )
}

export default Header;