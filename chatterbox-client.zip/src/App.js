import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';

//COMPONENTS & LAYOUT
import Root from './pages/root/Root';
import Room from './pages/room/Room';

import Header from './layout/header/Header';
import Footer from './layout/footer/Footer';
import Alerts from './layout/alerts/Alerts';

//CONTEXT STATES
import AuthState from './context/auth/AuthState';
import LoginState from './context/login/LoginState';
import AlertState from './context/alert/AlertState';

import './App.css';

//AUTH TOKEN
import setAuthToken from './utils/setAuthToken';
if(localStorage.token) {
    setAuthToken(localStorage.token);
}

//What does Switch do???
const App = () => (
    <AuthState>
        <LoginState>
            <AlertState>
                <Router>
                    <div className='App'>
                        <Header/>
                            <Switch>
                                <Route path='/' exact component={Root}/>
                                <Route path='/room' component={Room}/>
                            </Switch>
                        <Footer/>
                        <Alerts/>
                    </div>
                </Router>
            </AlertState>
        </LoginState>
    </AuthState>
)

export default App;