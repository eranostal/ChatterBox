import React from 'react';

import './Footer.css';

const Footer = () => {

    let d = new Date();

    return (
        <footer className='main-footer'>
            Copyright {d.getFullYear()} Keith Novack Company [ALERT BOX]
        </footer>
    )
}

export default Footer