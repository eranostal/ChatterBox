import React from 'react';

import User from '../user/User';

import './Users.css';

//Convert into a () component?
const Users = ({ users }) => {

    //console.log(users);

    return (
        <div className='users-list'>
            <div className='users-in-room'>
                Room Users: { users.length }
            </div>
            <div>
                {users.map((user, i) => <User key={i} user={user}/>)}
            </div>
        </div>
    )
};

export default Users;