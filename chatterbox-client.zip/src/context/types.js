//LOGIN TYPES
export const DISPLAY_LOGIN = 'DISPLAY_LOGIN';
export const HIDE_LOGIN = 'HIDE_LOGIN';
export const DISPLAY_FORM = 'DISPLAY_FORM'; //Shows either login or register in the login box.
//AUTH TYPES
export const REGISTER_SUCCESS = 'REGISTER_SUCCESS';
export const REGISTER_FAIL = 'REGISTER_FAIL';
export const USER_LOADED = 'LOGIN_USER';
export const AUTH_ERROR = 'AUTH_ERROR';
export const LOGIN_SUCCESS = 'LOGIN_SUCCESS';
export const LOGIN_FAIL = 'LOGIN_FAIL';
export const LOGOUT = 'LOGOUT';
export const UPDATE_SUCCESS = 'UPDATE_USER';
export const UPDATE_FAIL = 'UPDATE_FAIL';
//ALERT TYPES
export const SET_ALERT = 'SET_ALERT';
export const REMOVE_ALERT = 'REMOVE_ALERT'