import React from 'react';

import './Message.css';

const Message = ({ message: { user, text }, name }) => {

    let isSentByCurrentUser = false;

    const trimmedName = name.trim().toLowerCase();

    if(user === trimmedName) {
        isSentByCurrentUser = true;
    }

    return (
        isSentByCurrentUser ? (
            <div className='message'>
                <label className='user-name you'>{user}:</label>
                <span>
                    {text}
                </span>
            </div>
        ) : (
            <div className='message'> {/* maybe align message right */}
                <label className='user-name'>{user}:</label>
                <span>
                    {text}
                </span>
            </div>
        )
    )
}

export default Message;