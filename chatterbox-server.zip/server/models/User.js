const mongoose = require('mongoose');

const UserSchema = mongoose.Schema({
    email: {
        type: String,
        required: true,
        unique: true
    },
    userName: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    },
    firstName: {
        type: String
    },
    lastName: {
        type: String
    },
    dob: {
        type: Date,
        required: true,
        default: Date.now
    },
    joinDate: {
        type: Date,
        default: Date.now
    }

});

module.exports = mongoose.Model('user', UserSchema);