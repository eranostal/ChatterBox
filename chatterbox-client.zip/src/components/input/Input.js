import React from 'react';

import './Input.css';

const Input = ({ message, setMessage, sendMessage }) => (
    <form className='input-form'>
        <input
        className='input'
        type='text'
        placeholder='Type a message...'
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        onKeyPress={(e) => e.key === 'Enter' ? sendMessage(e) : null}
        />
        <input type='button' className='send-message' onClick={(e) => sendMessage(e)} value='Send'/>
    </form>
);

export default Input;