import React from 'react';

const ChatBox = () => {

    return (
        <div></div>
    )
}

export default ChatBox;