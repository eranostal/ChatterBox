import React from 'react';

import './VideoChat.css';

const VideoChat = () => {

    return (
        <div className='videos-box'>
            [text button]
        </div>
    )
}

export default VideoChat;